.. tareaPPS3 documentation master file, created by
   sphinx-quickstart on Mon Nov  2 11:05:02 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

tareaPPS3 documentation
=======================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. autoclass:: programa_principal.py
   :members:
   :undoc-members:
   :private-members:

.. autoclass:: modulo_numeros.py
   :members:
   :undoc-members:
   :private-members: